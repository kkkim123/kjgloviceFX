import "./styles/index.css";
import App from './components/App'