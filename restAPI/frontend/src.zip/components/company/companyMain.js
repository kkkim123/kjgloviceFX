import React, { Component } from "react";
import Company from "./company";

class companyMain extends Component {
  render() {
    return (
      <section className="container">
        <Company />
      </section>
    );
  }
}

export default companyMain;
